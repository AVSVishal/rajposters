package com.avsvishalmedia.rajposters

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}