# Raj Poster Maker - V01

**पोस्टर बनाएं अपनी फोटो के साथ**

A Flutter application for creating beautiful posters with user's photo and name overlay.

## 📱 Version Information
- **Version:** 1.0.0+1
- **Package:** com.avsvishalmedia.rajposters
- **App Name:** Raj Poster
- **Target:** Android SDK 35
- **Minimum:** Android SDK 21 (Android 5.0)

## 🎯 Features

### ✅ Implemented Features:
1. **Dynamic Poster Loading** - Posters fetched from JSON at http://avsvishalmedia.com/rajposters/posters.json
2. **Category System** - Multiple categories: पार्टी बैनर, डेली पोस्ट, भक्ति सुविचार, शुभेच्छा, त्यौहार
3. **User Profile** - User can set their name and photo
4. **Feed UI** - Grid view showing all available posters
5. **Category Filter** - Filter posters by category
6. **Poster Preview** - View poster with user photo and name overlay
7. **Free/Premium System** - Free and Pro poster differentiation
8. **Photo Overlay** - User photo automatically positioned on posters
9. **Name Overlay** - User name displayed on posters with custom positioning
10. **Splash Screen** - Professional splash with Raj Poster branding

## 🏗️ Project Structure

```
RajPosterMaker/
├── lib/
│   ├── main.dart                       # App entry point
│   ├── models/
│   │   ├── poster_models.dart          # Poster, Category, UserProfile models
│   │   ├── app_models.dart             # Legacy models (kept for reference)
│   │   └── config_model.dart           # Config models
│   ├── screens/
│   │   ├── splash_screen.dart          # Splash screen with branding
│   │   ├── home_screen.dart            # Redirects to feed
│   │   ├── feed_screen.dart            # Main feed with categories & grid
│   │   ├── profile_setup_screen.dart   # User profile setup
│   │   └── poster_detail_screen.dart   # Poster preview & download
│   ├── services/
│   │   ├── poster_service.dart         # Poster data fetching
│   │   ├── user_service.dart           # User profile management
│   │   ├── database_service.dart       # SQLite database
│   │   ├── http_service.dart           # HTTP requests
│   │   └── config_service.dart         # Configuration
│   ├── widgets/
│   │   ├── loading_widget.dart         # Loading animations
│   │   └── error_widget.dart           # Error handling
│   └── utils/
│       ├── constants.dart              # App constants
│       └── colors.dart                 # Color palette
├── android/                            # Android configuration
├── assets/                             # Asset directories
└── pubspec.yaml                        # Dependencies
```

## 📦 Dependencies

```yaml
dependencies:
  http: ^1.1.0                     # HTTP requests
  path_provider: ^2.1.1           # File system access
  sqflite: ^2.3.0                 # SQLite database
  path: ^1.8.3                    # Path manipulation
  connectivity_plus: ^5.0.2       # Network connectivity
  shared_preferences: ^2.5.3      # Simple data storage
  cupertino_icons: ^1.0.2         # iOS style icons
  image_picker: ^1.0.7            # Image picker
  cached_network_image: ^3.3.1    # Cached images
```

## 🔧 Technical Specifications

### Environment
- **Flutter:** 3.32.7+
- **Dart:** 3.8.1+
- **Android Gradle Plugin:** 8.3.0
- **Gradle:** 8.6
- **Kotlin:** 1.9.22
- **Target SDK:** 35 (Android 15)
- **Minimum SDK:** 21 (Android 5.0)

### Package Information
- **Package Name:** com.avsvishalmedia.rajposters
- **App Name:** Raj Poster
- **App Label:** Raj Poster
- **Version Code:** 1
- **Version Name:** 1.0.0

## 📋 JSON Format

The app fetches poster data from: `http://avsvishalmedia.com/rajposters/posters.json`

### JSON Structure:
```json
{
  "version": "1.0.0",
  "last_updated": "2024-12-22",
  "categories": [
    {
      "id": "festival",
      "name": "त्यौहार",
      "icon": "🎊",
      "color": "#F44336"
    }
  ],
  "posters": [
    {
      "id": "dussehra_2024_1",
      "title": "Dussehra Special",
      "category_id": "festival",
      "image_url": "http://avsvishalmedia.com/rajposters/images/dussehra_1.jpg",
      "thumbnail_url": "http://avsvishalmedia.com/rajposters/images/thumbs/dussehra_1.jpg",
      "is_free": true,
      "user_photo_position": {
        "x": 50,
        "y": 30,
        "width": 80,
        "height": 80,
        "shape": "circle"
      },
      "user_name_position": {
        "x": 50,
        "y": 75,
        "font_size": 18,
        "color": "#FFFFFF",
        "align": "center"
      },
      "tags": ["dussehra", "festival"],
      "created_at": "2024-10-20"
    }
  ]
}
```

## 🚀 Setup Instructions

1. **Set Flutter SDK path:**
   ```
   cp android/local.properties.template android/local.properties
   ```
   Edit `local.properties` and set your Flutter SDK path

2. **Get dependencies:**
   ```bash
   flutter clean
   flutter pub get
   ```

3. **Run the app:**
   ```bash
   flutter run
   ```

4. **Build APK:**
   ```bash
   flutter build apk --release
   ```

## 🎨 App Flow

1. **Splash Screen** (3 seconds) → Shows "Raj Poster" branding
2. **Feed Screen** → Main screen with:
   - Horizontal category scrolling
   - Grid of posters (2 columns)
   - User photo overlay preview on each poster
   - Free/Pro badges
3. **Profile Setup** → User can set name and photo
4. **Poster Detail** → Full preview with overlay, download/share options

## ✅ Implementation Checklist

- ✅ Package name changed to com.avsvishalmedia.rajposters
- ✅ App name changed to "Raj Poster"
- ✅ JSON-based poster system implemented
- ✅ Category system with filtering
- ✅ User profile with photo picker
- ✅ Feed UI with grid layout
- ✅ Poster overlay functionality
- ✅ Free/Premium differentiation
- ✅ Splash screen with branding
- ✅ Data caching (3 hours)
- ✅ Error handling throughout

## 📝 Notes

- Poster images are fetched from the JSON URL
- User photo and name are stored locally using SharedPreferences
- Poster data is cached for 3 hours using SQLite
- The app works offline with cached data
- All UI text is in Hindi for better user experience
- Photo overlay positions are defined in JSON (percentage-based)

## 🎯 Future Enhancements

- Premium poster unlock system
- Poster editor for custom text
- Download functionality
- Share to social media
- Search functionality
- Favorites system
- Multiple user profiles

---

**Raj Poster V01** - Created on 2024-12-22
*AVS Vishal Media*
