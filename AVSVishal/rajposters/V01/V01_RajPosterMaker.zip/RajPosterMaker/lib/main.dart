import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';

void main() {
  runApp(RajPosterApp());
}

class RajPosterApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Raj Poster',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.light(
          primary: Color(0xFFFF5722),
          onPrimary: Color(0xFFFFFFFF),
          secondary: Color(0xFF9C27B0),
          onSecondary: Color(0xFFFFFFFF),
          surface: Color(0xFFFAFAFA),
          onSurface: Color(0xFF000000),
          background: Color(0xFFF5F5F5),
          onBackground: Color(0xFF000000),
          error: Color(0xFFD32F2F),
          onError: Color(0xFFFFFFFF),
        ),
        cardTheme: CardThemeData(
          color: Color(0xFFFFFFFF),
          elevation: 2.0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: Color(0xFFFFFFFF),
          foregroundColor: Color(0xFF000000),
          elevation: 1,
          centerTitle: false,
        ),
        scaffoldBackgroundColor: Color(0xFFF5F5F5),
      ),
      home: SplashScreen(),
    );
  }
}