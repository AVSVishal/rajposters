import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/poster_models.dart';

class UserService {
  static final UserService _instance = UserService._internal();
  factory UserService() => _instance;
  UserService._internal();

  static const String USER_PROFILE_KEY = 'user_profile';

  Future<UserProfile> getUserProfile() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final profileJson = prefs.getString(USER_PROFILE_KEY);
      
      if (profileJson != null) {
        return UserProfile.fromJson(json.decode(profileJson));
      }
      
      return UserProfile(name: 'आपका नाम');
    } catch (e) {
      print('Error getting user profile: $e');
      return UserProfile(name: 'आपका नाम');
    }
  }

  Future<bool> saveUserProfile(UserProfile profile) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(USER_PROFILE_KEY, json.encode(profile.toJson()));
      return true;
    } catch (e) {
      print('Error saving user profile: $e');
      return false;
    }
  }

  Future<bool> updateUserName(String name) async {
    try {
      final profile = await getUserProfile();
      final updatedProfile = UserProfile(
        name: name,
        photoPath: profile.photoPath,
      );
      return await saveUserProfile(updatedProfile);
    } catch (e) {
      print('Error updating user name: $e');
      return false;
    }
  }

  Future<bool> updateUserPhoto(String photoPath) async {
    try {
      final profile = await getUserProfile();
      final updatedProfile = UserProfile(
        name: profile.name,
        photoPath: photoPath,
      );
      return await saveUserProfile(updatedProfile);
    } catch (e) {
      print('Error updating user photo: $e');
      return false;
    }
  }

  Future<bool> clearUserProfile() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(USER_PROFILE_KEY);
      return true;
    } catch (e) {
      print('Error clearing user profile: $e');
      return false;
    }
  }
}
