import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/poster_models.dart';
import 'http_service.dart';
import 'database_service.dart';

class PosterService {
  static final PosterService _instance = PosterService._internal();
  factory PosterService() => _instance;
  PosterService._internal();

  final HttpService _httpService = HttpService();
  final DatabaseService _databaseService = DatabaseService();
  
  static const String POSTER_DATA_URL = 'http://avsvishalmedia.com/rajposters/posters.json';
  static const String CACHE_KEY = 'poster_data';
  static const int CACHE_HOURS = 3;

  Future<PosterData?> getPosterData() async {
    try {
      if (await _isCacheValid()) {
        final cached = await _databaseService.getConfigCache(CACHE_KEY);
        if (cached != null) {
          return PosterData.fromJson(json.decode(cached['config_data']));
        }
      }

      final freshData = await _httpService.fetchJson(POSTER_DATA_URL);
      if (freshData != null) {
        await _databaseService.saveConfigCache(
          CACHE_KEY,
          json.encode(freshData),
        );
        return PosterData.fromJson(freshData);
      }

      final cached = await _databaseService.getConfigCache(CACHE_KEY);
      if (cached != null) {
        return PosterData.fromJson(json.decode(cached['config_data']));
      }

      return null;
    } catch (e) {
      print('Error getting poster data: $e');
      
      final cached = await _databaseService.getConfigCache(CACHE_KEY);
      if (cached != null) {
        return PosterData.fromJson(json.decode(cached['config_data']));
      }
      
      return null;
    }
  }

  Future<bool> _isCacheValid() async {
    return await _databaseService.isCacheValid(CACHE_KEY, CACHE_HOURS);
  }

  Future<void> clearCache() async {
    final db = await _databaseService.database;
    await db.delete(
      'config_cache',
      where: 'config_type = ?',
      whereArgs: [CACHE_KEY],
    );
  }

  Future<List<Poster>> getPostersByCategory(String categoryId, PosterData posterData) async {
    return posterData.posters.where((p) => p.categoryId == categoryId).toList();
  }

  Future<List<Poster>> searchPosters(String query, PosterData posterData) async {
    final lowerQuery = query.toLowerCase();
    return posterData.posters.where((p) {
      return p.title.toLowerCase().contains(lowerQuery) ||
             p.tags.any((tag) => tag.toLowerCase().contains(lowerQuery));
    }).toList();
  }
}
