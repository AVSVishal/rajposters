class PosterCategory {
  final String id;
  final String name;
  final String icon;
  final String color;

  PosterCategory({
    required this.id,
    required this.name,
    required this.icon,
    required this.color,
  });

  factory PosterCategory.fromJson(Map<String, dynamic> json) {
    return PosterCategory(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      icon: json['icon'] ?? '📋',
      color: json['color'] ?? '#2196F3',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'icon': icon,
      'color': color,
    };
  }
}

class PhotoPosition {
  final double x;
  final double y;
  final double width;
  final double height;
  final String shape;

  PhotoPosition({
    required this.x,
    required this.y,
    required this.width,
    required this.height,
    required this.shape,
  });

  factory PhotoPosition.fromJson(Map<String, dynamic> json) {
    return PhotoPosition(
      x: (json['x'] ?? 50).toDouble(),
      y: (json['y'] ?? 50).toDouble(),
      width: (json['width'] ?? 80).toDouble(),
      height: (json['height'] ?? 80).toDouble(),
      shape: json['shape'] ?? 'circle',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'x': x,
      'y': y,
      'width': width,
      'height': height,
      'shape': shape,
    };
  }
}

class NamePosition {
  final double x;
  final double y;
  final double fontSize;
  final String color;
  final String align;

  NamePosition({
    required this.x,
    required this.y,
    required this.fontSize,
    required this.color,
    required this.align,
  });

  factory NamePosition.fromJson(Map<String, dynamic> json) {
    return NamePosition(
      x: (json['x'] ?? 50).toDouble(),
      y: (json['y'] ?? 70).toDouble(),
      fontSize: (json['font_size'] ?? 16).toDouble(),
      color: json['color'] ?? '#FFFFFF',
      align: json['align'] ?? 'center',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'x': x,
      'y': y,
      'font_size': fontSize,
      'color': color,
      'align': align,
    };
  }
}

class Poster {
  final String id;
  final String title;
  final String categoryId;
  final String imageUrl;
  final String thumbnailUrl;
  final bool isFree;
  final PhotoPosition userPhotoPosition;
  final NamePosition userNamePosition;
  final List<String> tags;
  final String? eventDate;
  final String createdAt;

  Poster({
    required this.id,
    required this.title,
    required this.categoryId,
    required this.imageUrl,
    required this.thumbnailUrl,
    required this.isFree,
    required this.userPhotoPosition,
    required this.userNamePosition,
    required this.tags,
    this.eventDate,
    required this.createdAt,
  });

  factory Poster.fromJson(Map<String, dynamic> json) {
    return Poster(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      categoryId: json['category_id'] ?? '',
      imageUrl: json['image_url'] ?? '',
      thumbnailUrl: json['thumbnail_url'] ?? '',
      isFree: json['is_free'] ?? true,
      userPhotoPosition: PhotoPosition.fromJson(json['user_photo_position'] ?? {}),
      userNamePosition: NamePosition.fromJson(json['user_name_position'] ?? {}),
      tags: List<String>.from(json['tags'] ?? []),
      eventDate: json['event_date'],
      createdAt: json['created_at'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'category_id': categoryId,
      'image_url': imageUrl,
      'thumbnail_url': thumbnailUrl,
      'is_free': isFree,
      'user_photo_position': userPhotoPosition.toJson(),
      'user_name_position': userNamePosition.toJson(),
      'tags': tags,
      'event_date': eventDate,
      'created_at': createdAt,
    };
  }
}

class PosterData {
  final String version;
  final String lastUpdated;
  final List<PosterCategory> categories;
  final List<Poster> posters;

  PosterData({
    required this.version,
    required this.lastUpdated,
    required this.categories,
    required this.posters,
  });

  factory PosterData.fromJson(Map<String, dynamic> json) {
    return PosterData(
      version: json['version'] ?? '1.0.0',
      lastUpdated: json['last_updated'] ?? '',
      categories: (json['categories'] as List<dynamic>?)
          ?.map((c) => PosterCategory.fromJson(c))
          .toList() ?? [],
      posters: (json['posters'] as List<dynamic>?)
          ?.map((p) => Poster.fromJson(p))
          .toList() ?? [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'version': version,
      'last_updated': lastUpdated,
      'categories': categories.map((c) => c.toJson()).toList(),
      'posters': posters.map((p) => p.toJson()).toList(),
    };
  }
}

class UserProfile {
  final String name;
  final String? photoPath;

  UserProfile({
    required this.name,
    this.photoPath,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      name: json['name'] ?? 'आपका नाम',
      photoPath: json['photo_path'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'photo_path': photoPath,
    };
  }
}
