import 'package:flutter/material.dart';
import '../models/poster_models.dart';
import '../services/poster_service.dart';
import '../services/user_service.dart';
import '../widgets/loading_widget.dart';
import '../widgets/error_widget.dart';
import 'profile_setup_screen.dart';
import 'poster_detail_screen.dart';
import 'dart:io';

class FeedScreen extends StatefulWidget {
  @override
  _FeedScreenState createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  final PosterService _posterService = PosterService();
  final UserService _userService = UserService();
  
  PosterData? _posterData;
  UserProfile? _userProfile;
  String? _selectedCategoryId;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final posterData = await _posterService.getPosterData();
      final userProfile = await _userService.getUserProfile();

      if (posterData == null) {
        setState(() {
          _error = 'पोस्टर डेटा लोड नहीं हो सका';
          _isLoading = false;
        });
        return;
      }

      setState(() {
        _posterData = posterData;
        _userProfile = userProfile;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'कुछ गलत हो गया। कृपया पुनः प्रयास करें।';
        _isLoading = false;
      });
    }
  }

  List<Poster> _getFilteredPosters() {
    if (_posterData == null) return [];
    
    if (_selectedCategoryId == null) {
      return _posterData!.posters;
    }
    
    return _posterData!.posters
        .where((p) => p.categoryId == _selectedCategoryId)
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: Color(0xFFFFFFFF),
        elevation: 1,
        leading: Padding(
          padding: EdgeInsets.all(8.0),
          child: Icon(Icons.menu, color: Color(0xFF000000)),
        ),
        title: Row(
          children: [
            Text(
              'पोस्टर',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFF000000),
              ),
            ),
            Text(
              'App',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.normal,
                color: Color(0xFF9C27B0),
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.person_outline, color: Color(0xFF2196F3)),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfileSetupScreen()),
              );
              _loadData();
            },
          ),
          IconButton(
            icon: Icon(Icons.notifications_outlined, color: Color(0xFFFFB300)),
            onPressed: () {},
          ),
          IconButton(
            icon: Icon(Icons.settings_outlined, color: Color(0xFF757575)),
            onPressed: () {},
          ),
        ],
      ),
      body: _isLoading
          ? LoadingWidget(message: 'पोस्टर लोड हो रहे हैं...')
          : _error != null
              ? AppErrorWidget(
                  message: _error!,
                  onRetry: _loadData,
                )
              : RefreshIndicator(
                  onRefresh: _loadData,
                  child: Column(
                    children: [
                      if (_posterData != null && _posterData!.categories.isNotEmpty)
                        _buildCategorySection(),
                      Expanded(
                        child: _buildPosterGrid(),
                      ),
                    ],
                  ),
                ),
    );
  }

  Widget _buildCategorySection() {
    return Container(
      color: Color(0xFFFFFFFF),
      padding: EdgeInsets.symmetric(vertical: 12),
      child: Column(
        children: [
          Container(
            height: 100,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: 8),
              itemCount: _posterData!.categories.length,
              itemBuilder: (context, index) {
                final category = _posterData!.categories[index];
                final isSelected = _selectedCategoryId == category.id;
                
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      if (_selectedCategoryId == category.id) {
                        _selectedCategoryId = null;
                      } else {
                        _selectedCategoryId = category.id;
                      }
                    });
                  },
                  child: Container(
                    width: 80,
                    margin: EdgeInsets.symmetric(horizontal: 6),
                    child: Column(
                      children: [
                        Container(
                          width: 60,
                          height: 60,
                          decoration: BoxDecoration(
                            color: _hexToColor(category.color).withOpacity(isSelected ? 1.0 : 0.9),
                            shape: BoxShape.circle,
                            border: isSelected
                                ? Border.all(color: Color(0xFF000000), width: 2)
                                : null,
                          ),
                          child: Center(
                            child: Text(
                              category.icon,
                              style: TextStyle(fontSize: 28),
                            ),
                          ),
                        ),
                        SizedBox(height: 6),
                        Text(
                          category.name,
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                            color: Color(0xFF000000),
                          ),
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPosterGrid() {
    final posters = _getFilteredPosters();
    
    if (posters.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.image_not_supported, size: 64, color: Color(0xFF9E9E9E)),
            SizedBox(height: 16),
            Text(
              'कोई पोस्टर नहीं मिला',
              style: TextStyle(fontSize: 16, color: Color(0xFF757575)),
            ),
          ],
        ),
      );
    }

    return GridView.builder(
      padding: EdgeInsets.all(12),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.75,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: posters.length,
      itemBuilder: (context, index) {
        final poster = posters[index];
        return _buildPosterCard(poster);
      },
    );
  }

  Widget _buildPosterCard(Poster poster) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PosterDetailScreen(
              poster: poster,
              userProfile: _userProfile!,
            ),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: Color(0xFFFFFFFF),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Color(0x1A000000),
              blurRadius: 8,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Stack(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Container(
                width: double.infinity,
                height: double.infinity,
                color: Color(0xFFE0E0E0),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.image, size: 40, color: Color(0xFF9E9E9E)),
                      SizedBox(height: 8),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8),
                        child: Text(
                          poster.title,
                          style: TextStyle(
                            fontSize: 14,
                            color: Color(0xFF424242),
                            fontWeight: FontWeight.w500,
                          ),
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            if (_userProfile != null && _userProfile!.photoPath != null)
              Positioned(
                top: 12,
                left: 12,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Color(0xFFFFFFFF), width: 2),
                    image: DecorationImage(
                      image: FileImage(File(_userProfile!.photoPath!)),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            if (!poster.isFree)
              Positioned(
                top: 8,
                right: 8,
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Color(0xFFFF5722),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'PRO',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFFFFFFF),
                    ),
                  ),
                ),
              )
            else
              Positioned(
                top: 8,
                left: 8,
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Color(0xFF4CAF50),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'Free',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFFFFFFF),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Color _hexToColor(String hex) {
    hex = hex.replaceAll('#', '');
    if (hex.length == 6) {
      hex = 'FF$hex';
    }
    return Color(int.parse(hex, radix: 16));
  }
}
