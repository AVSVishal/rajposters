import 'package:flutter/material.dart';
import 'dart:io';
import '../models/poster_models.dart';

class PosterDetailScreen extends StatefulWidget {
  final Poster poster;
  final UserProfile userProfile;

  const PosterDetailScreen({
    Key? key,
    required this.poster,
    required this.userProfile,
  }) : super(key: key);

  @override
  _PosterDetailScreenState createState() => _PosterDetailScreenState();
}

class _PosterDetailScreenState extends State<PosterDetailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF000000),
      appBar: AppBar(
        backgroundColor: Color(0xFF000000),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Color(0xFFFFFFFF)),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          widget.poster.title,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: Color(0xFFFFFFFF),
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.share, color: Color(0xFFFFFFFF)),
            onPressed: _sharePoster,
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: _buildPosterPreview(),
            ),
          ),
          _buildBottomActions(),
        ],
      ),
    );
  }

  Widget _buildPosterPreview() {
    return Container(
      margin: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Color(0xFFE0E0E0),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Color(0x4D000000),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: AspectRatio(
        aspectRatio: 0.75,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Stack(
            children: [
              Container(
                width: double.infinity,
                height: double.infinity,
                color: Color(0xFFE0E0E0),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.image, size: 80, color: Color(0xFF9E9E9E)),
                      SizedBox(height: 16),
                      Text(
                        widget.poster.title,
                        style: TextStyle(
                          fontSize: 18,
                          color: Color(0xFF424242),
                          fontWeight: FontWeight.w600,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 8),
                      Text(
                        'पोस्टर टेम्पलेट',
                        style: TextStyle(
                          fontSize: 14,
                          color: Color(0xFF757575),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              _buildUserPhotoOverlay(),
              _buildUserNameOverlay(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUserPhotoOverlay() {
    if (widget.userProfile.photoPath == null) {
      return Positioned(
        left: _getPositionX(widget.poster.userPhotoPosition.x),
        top: _getPositionY(widget.poster.userPhotoPosition.y),
        child: Container(
          width: widget.poster.userPhotoPosition.width,
          height: widget.poster.userPhotoPosition.height,
          decoration: BoxDecoration(
            shape: widget.poster.userPhotoPosition.shape == 'circle'
                ? BoxShape.circle
                : BoxShape.rectangle,
            color: Color(0xFF9E9E9E),
            border: Border.all(color: Color(0xFFFFFFFF), width: 3),
          ),
          child: Icon(
            Icons.person,
            size: widget.poster.userPhotoPosition.width * 0.6,
            color: Color(0xFFFFFFFF),
          ),
        ),
      );
    }

    return Positioned(
      left: _getPositionX(widget.poster.userPhotoPosition.x),
      top: _getPositionY(widget.poster.userPhotoPosition.y),
      child: Container(
        width: widget.poster.userPhotoPosition.width,
        height: widget.poster.userPhotoPosition.height,
        decoration: BoxDecoration(
          shape: widget.poster.userPhotoPosition.shape == 'circle'
              ? BoxShape.circle
              : BoxShape.rectangle,
          border: Border.all(color: Color(0xFFFFFFFF), width: 3),
          image: DecorationImage(
            image: FileImage(File(widget.userProfile.photoPath!)),
            fit: BoxFit.cover,
          ),
          boxShadow: [
            BoxShadow(
              color: Color(0x4D000000),
              blurRadius: 10,
              offset: Offset(0, 4),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUserNameOverlay() {
    final namePosition = widget.poster.userNamePosition;
    final textColor = _hexToColor(namePosition.color);
    
    return Positioned(
      left: namePosition.align == 'left' 
          ? _getPositionX(namePosition.x)
          : namePosition.align == 'right'
              ? null
              : _getPositionX(namePosition.x) - 100,
      right: namePosition.align == 'right'
          ? _getPositionX(100 - namePosition.x)
          : null,
      top: _getPositionY(namePosition.y),
      width: namePosition.align == 'center' ? 200 : null,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: Color(0x80000000),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          widget.userProfile.name,
          style: TextStyle(
            fontSize: namePosition.fontSize,
            fontWeight: FontWeight.bold,
            color: textColor,
            shadows: [
              Shadow(
                color: Color(0xFF000000),
                blurRadius: 4,
                offset: Offset(1, 1),
              ),
            ],
          ),
          textAlign: namePosition.align == 'center'
              ? TextAlign.center
              : namePosition.align == 'right'
                  ? TextAlign.right
                  : TextAlign.left,
        ),
      ),
    );
  }

  Widget _buildBottomActions() {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Color(0xFF1A1A1A),
        boxShadow: [
          BoxShadow(
            color: Color(0x4D000000),
            blurRadius: 10,
            offset: Offset(0, -5),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (!widget.poster.isFree)
            Container(
              padding: EdgeInsets.all(12),
              margin: EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: Color(0xFFFF5722),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Icon(Icons.lock, color: Color(0xFFFFFFFF)),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'यह प्रीमियम पोस्टर है। डाउनलोड करने के लिए PRO खरीदें',
                      style: TextStyle(
                        color: Color(0xFFFFFFFF),
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: widget.poster.isFree ? _downloadPoster : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF4CAF50),
                    foregroundColor: Color(0xFFFFFFFF),
                    padding: EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    elevation: 0,
                  ),
                  icon: Icon(Icons.download),
                  label: Text(
                    'डाउनलोड',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _editPoster,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF9C27B0),
                    foregroundColor: Color(0xFFFFFFFF),
                    padding: EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    elevation: 0,
                  ),
                  icon: Icon(Icons.edit),
                  label: Text(
                    'एडिट करें',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  double _getPositionX(double percentage) {
    return (percentage / 100) * MediaQuery.of(context).size.width * 0.8;
  }

  double _getPositionY(double percentage) {
    return (percentage / 100) * MediaQuery.of(context).size.width * 0.8 * 1.33;
  }

  Color _hexToColor(String hex) {
    hex = hex.replaceAll('#', '');
    if (hex.length == 6) {
      hex = 'FF$hex';
    }
    return Color(int.parse(hex, radix: 16));
  }

  void _downloadPoster() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('पोस्टर डाउनलोड हो रहा है...'),
        backgroundColor: Color(0xFF4CAF50),
      ),
    );
  }

  void _sharePoster() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('पोस्टर शेयर करें...'),
        backgroundColor: Color(0xFF2196F3),
      ),
    );
  }

  void _editPoster() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('पोस्टर एडिटर जल्द आ रहा है...'),
        backgroundColor: Color(0xFF9C27B0),
      ),
    );
  }
}
